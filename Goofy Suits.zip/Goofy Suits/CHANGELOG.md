## v1.2.0 Patch
- Added Galaxy Suit!

## v1.0.1 Patch
- Fixed Ghillie and PinStripe showing up twice.

## v1.0.0 Release 
- Release

</details>