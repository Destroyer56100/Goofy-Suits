# Goofy Suits v1.0.0
### Adds some goofy suits

## Suits
- Bracken Suit
- More Suits Coming Soon!